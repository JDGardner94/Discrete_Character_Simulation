library(ggplot2)
# Comparing the average rate parameter values for each individual scenario 
p <- ggplot(Simulation_RJMCMC_Rates_experimental.results, aes(x = RateParam, y = AvgRate, color = "black")) + geom_boxplot(notch = TRUE) + labs(y = "Average Rate", x = "Rate Parameter") + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"), legend.position = "none")
q <- ggplot(Simulation_RJMCMC_Run180_results, aes(x = RateParam, y = Rate, color = RateParam)) + geom_boxplot(notch = TRUE) + labs(y = "Rate", x = "Rate Parameter") + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"), legend.position = "none")
# notch: confidence interval = median +/- 1.58*IQR/sqrt(n)
p + scale_color_grey(start=0, end=0) 
q

n <- 1000

median(Darwin_q12)
# 0.0004884935
min(Darwin_q12)
# 0
max(Darwin_q12)
# 0.02172371
median(Darwin_q13)
# 0.00063249
min(Darwin_q13)
# 0
max(Darwin_q13)
# 0.02701563
median(Darwin_q21)
# 0.5883912
min(Darwin_q21)
# 0.05916077
max(Darwin_q21)
# 25.47428
median(Darwin_q24)
# 0.5793844
min(Darwin_q24)
# 0.08680295
max(Darwin_q24)
# 34.35876
median(Darwin_q31)
# 0.6019553
min(Darwin_q31)
# 0.05959877
max(Darwin_q31)
# 26.52105
median(Darwin_q34)
# 0.5885145
min(Darwin_q34)
# 0.08676979
max(Darwin_q34)
# 34.48036
median(Darwin_q42)
# 0.0001196595
min(Darwin_q42)
# 0
max(Darwin_q42)
# 0.01529992
median(Darwin_q43)
# 0.000119689
min(Darwin_q43)
# 0
max(Darwin_q43)
# 0.01314988

median(Unrepburst_q12)
# 0.001109875
min(Unrepburst_q12)
# 0
max(Unrepburst_q12)
# 0.09332752
median(Unrepburst_q13)
# 0.001612201
min(Unrepburst_q13)
# 0
max(Unrepburst_q13)
# 2.992297
median(Unrepburst_q21)
# 2.007018
min(Unrepburst_q21)
# 0.0646245
max(Unrepburst_q21)
# 46.48017
median(Unrepburst_q24)
# 2.225008
min(Unrepburst_q24)
# 0.06236331
max(Unrepburst_q24)
# 46.44234
median(Unrepburst_q31)
# 0.001758584
min(Unrepburst_q31)
# 0
max(Unrepburst_q31)
# 7.038438
median(Unrepburst_q34)
# 3.485944
min(Unrepburst_q34)
# 0.1003458
max(Unrepburst_q34)
# 46.44281
median(Unrepburst_q42)
# 0.002671141
min(Unrepburst_q42)
# 0
max(Unrepburst_q42)
# 0.0549153
median(Unrepburst_q43)
# 3.485858
min(Unrepburst_q43)
# 0.1003087
max(Unrepburst_q43)
# 46.4797

median(DarwinFossil_q12)
# 8.803356
min(DarwinFossil_q12)
# 5.718e-06
max(DarwinFossil_q12)
# 17.48849
median(DarwinFossil_q13)
# 8.803231
min(DarwinFossil_q13)
# 0.1182058
max(DarwinFossil_q13)
# 17.59334
median(DarwinFossil_q21)
# 0
min(DarwinFossil_q21)
# 0
max(DarwinFossil_q21)
# 0
median(DarwinFossil_q24)
# 9.171665
min(DarwinFossil_q24)
# 1.3412e-05
max(DarwinFossil_q24)
# 68.48093
median(DarwinFossil_q31)
# 0
min(DarwinFossil_q31)
# 0
max(DarwinFossil_q31)
# 0
median(DarwinFossil_q34)
# 9.147361
min(DarwinFossil_q34)
# 1.3412e-05
max(DarwinFossil_q34)
# 80.1828
median(DarwinFossil_q42)
# 0
min(DarwinFossil_q42)
# 0
max(DarwinFossil_q42)
# 0
median(DarwinFossil_q43)
# 0
min(DarwinFossil_q43)
# 0
max(DarwinFossil_q43)
# 0
