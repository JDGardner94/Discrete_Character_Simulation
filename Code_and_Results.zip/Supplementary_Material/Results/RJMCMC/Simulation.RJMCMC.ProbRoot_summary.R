library(ggplot2)
# Comparing the average root state probability values for each scenario 
p <- ggplot(Simulation_RJMCMC_ProbRoot_results, aes(x = Scenario_State, y = Probability, color = Scenario_State)) + geom_boxplot(notch = TRUE) + labs(y = "Average Probability") + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "white"), axis.text.y = element_text(colour = "black"), legend.background = element_rect(fill = "white"), legend.key = element_rect(fill = "white", colour = "white"))
# notch: confidence interval = median +/- 1.58*IQR/sqrt(n)
p 

n <- 1000
median(DarwinRoot00)
  # 0.04302236
min(DarwinRoot00)
  # 0
max(DarwinRoot00)
  # 0.6754814

median(DarwinRoot01)
  # 0.4730167
min(DarwinRoot01)
  # 0.1555005
max(DarwinRoot01)
  # 0.9195517

median(DarwinRoot10)
  # 0.4725365
min(DarwinRoot10)
  # 0.07929303
max(DarwinRoot10)
  # 0.5352173

median(DarwinRoot11)
  # 0.000290921
min(DarwinRoot11)
  # 0
max(DarwinRoot11)
  # 0.1045686

median(UnrepburstRoot00)
  # 0.6160182
min(UnrepburstRoot00)
  # 0
max(UnrepburstRoot00)
  # 0.8459441

median(UnrepburstRoot01)
  # 0.261599
min(UnrepburstRoot01)
  # 0.1433907
max(UnrepburstRoot01)
  # 1

median(UnrepburstRoot10)
  # 0.02970848
min(UnrepburstRoot10)
  # 0
max(UnrepburstRoot10)
  # 0.3082398

median(UnrepburstRoot11)
  # 0.02600493
min(UnrepburstRoot11)
  # 0
max(UnrepburstRoot11)
  # 0.3008837


