library(ggplot2)
# Comparing positive and negative controls with Darwin's and unreplicated burst scenarios
p <- ggplot(Simulation_PagelsDiscrete_results, aes(x = Scenario, y = p, color = Scenario)) + geom_boxplot(notch = TRUE) + labs(y = "p value") + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "white"), axis.text.y = element_text(colour = "black"), legend.background = element_rect(fill = "white"), legend.key = element_rect(fill = "white", colour = "white"))
# notch: confidence interval = median +/- 1.58*IQR/sqrt(n)
p + geom_hline(yintercept = 0.05, linetype = 5, color = "gray") + scale_y_continuous(breaks = c(0.05,0.5,1.0)) + scale_x_discrete(limits=c("Positive Control", "Negative Control", "Darwin's Scenario", "Unreplicated Burst"))
#p + scale_x_discrete(limits=c("Darwin's Scenario", "Unrep/8", "Unrep/6", "Unrep/4", "Unrep/2", "Unreplicated Burst"))

p <- ggplot(Simulation_PagelsDiscrete_results, aes(x = Scenario, y = p)) + geom_tufteboxplot() + labs(y = "p-value", x = NULL) + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"), legend.position = "none")
#A point indicating the median, a gap indicating the interquartile range, and lines for whiskers
p + geom_hline(yintercept = 0.05, linetype = 5, color = "gray") + scale_x_discrete(limits=c("Positive Control", "Negative Control", "Darwin's Scenario", "Unreplicated Burst"))

Simulation_PagelsDiscrete_results$Scenario_f = factor(Simulation_PagelsDiscrete_results$Scenario, levels=c("Positive Control", "Negative Control", "Darwin's Scenario", "Unreplicated Burst"))

p<-ggplot(Simulation_PagelsDiscrete_results, aes(x=p))+ geom_histogram(position = "dodge", alpha = 0.5) + labs(x = "p-value") + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"), legend.background = element_rect(fill = "white"), legend.key = element_rect(fill = "white", colour = "white"))
p + scale_x_continuous(breaks = c(0.05,0.5,1)) + scale_y_continuous(breaks = c(0,500,1000)) +
  geom_histogram(color="black", fill="gray")+
  facet_grid(Scenario_f ~ .) 

# Comparing Darwin's and unreplicated burst scenarios
p2 <- ggplot(Simulation_PagelsDiscrete_results, aes(x = p, fill = Scenario, color = Scenario)) + geom_histogram(position = "dodge", alpha = 0.5) + labs(x = "p value") + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"), legend.background = element_rect(fill = "white"), legend.key = element_rect(fill = "white", colour = "white"))
p2 + geom_vline(xintercept = 0.05, linetype = 5, color = "gray") + scale_x_continuous(breaks = c(0,0.05,0.075)) + scale_y_continuous(breaks = c(0,500,1000)) + scale_color_grey(start=0.8, end=0.2) + scale_fill_grey(start=0.8, end=0.2)

n <- 1000
median(p.Positive)
  # 0 
median(p.Negative)
  # 0.7795198

median(p.Darwin)
  # 0.002066653
min(p.Darwin)
  # 4.339333e-07
max(p.Darwin)
  # 0.06453808
median(p.Unrepburst)
  # 4.811172e-08
min(p.Unrepburst)
  # 3.541611e-14
max(p.Unrepburst)
  # 0.0886106

median(p.Unrep8)
  # 4.826949e-05
median(p.Unrep6)
  # 1.563062e-05
median(p.Unrep4)
  # 9.728824e-07
median(p.Unrep2)
  # 4.548069e-08

error.positive <- qt(0.975,df=n-1)*sd(p.Positive)/sqrt(n)
left.positive <- mean(p.Positive) - error.positive
right.positive <- mean(p.Positive) + error.positive
  # 95% CI: 0,0
error.negative <- qt(0.975,df=n-1)*sd(p.Negative)/sqrt(n)
left.negative <- mean(p.Negative) - error.negative
right.negative <- mean(p.Negative) + error.negative
  # 95% CI: 0.6772624,0.7114111
error.Darwin <- qt(0.975,df=n-1)*sd(p.Darwin)/sqrt(n)
left.Darwin <- mean(p.Darwin) - error.Darwin
right.Darwin <- mean(p.Darwin) + error.Darwin
  # 95% CI: 0.003535333,0.004166455
error.Unrepburst <- qt(0.975,df=n-1)*sd(p.Unrepburst)/sqrt(n)
left.Unrepburst <- mean(p.Unrepburst) - error.Unrepburst
right.Unrepburst <- mean(p.Unrepburst) + error.Unrepburst
  # 95% CI: -2.033859e-06,0.0003610899


error.Unrepburst8 <- qt(0.975,df=n-1)*sd(p.Unrep8)/sqrt(n)
left.Unrepburst8 <- mean(p.Unrep8) - error.Unrepburst8
right.Unrepburst8 <- mean(p.Unrep8) + error.Unrepburst8
  # 95% CI: 0.0006314965,0.001039485
error.Unrepburst6 <- qt(0.975,df=n-1)*sd(p.Unrep6)/sqrt(n)
left.Unrepburst6 <- mean(p.Unrep6) - error.Unrepburst6
right.Unrepburst6 <- mean(p.Unrep6) + error.Unrepburst6
  # 95% CI: 0.0005203372,0.0009989152
error.Unrepburst4 <- qt(0.975,df=n-1)*sd(p.Unrep4)/sqrt(n)
left.Unrepburst4 <- mean(p.Unrep4) - error.Unrepburst4
right.Unrepburst4 <- mean(p.Unrep4) + error.Unrepburst4
  # 95% CI: 0.0001094651,0.0002642003
error.Unrepburst2 <- qt(0.975,df=n-1)*sd(p.Unrep2)/sqrt(n)
left.Unrepburst2 <- mean(p.Unrep2) - error.Unrepburst2
right.Unrepburst2 <- mean(p.Unrep2) + error.Unrepburst2
  # 95% CI: 3.261167e-05,0.0001355288
