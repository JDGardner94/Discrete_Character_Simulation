library(ggplot2)
library(ggthemes)
p <- ggplot(Simulation_Threshold_results, aes(x = Scenario, y = r)) + geom_tufteboxplot() + labs(y = "r-value", x = NULL) + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"), legend.position = "none")
#A point indicating the median, a gap indicating the interquartile range, and lines for whiskers
p + geom_hline(yintercept = 0, linetype = 5, color = "gray") + scale_x_discrete(limits=c("Positive Control", "Negative Control", "Darwin's Scenario", "Unreplicated Burst"))

Simulation_Threshold_results$Scenario_f = factor(Simulation_Threshold_results$Scenario, levels=c("Positive Control", "Negative Control", "Darwin's Scenario", "Unreplicated Burst"))

p<-ggplot(Simulation_Threshold_results, aes(x=r))+ geom_histogram(position = "dodge", alpha = 0.5) + labs(x = "p-value") + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"), legend.background = element_rect(fill = "white"), legend.key = element_rect(fill = "white", colour = "white"))
p + scale_x_continuous(breaks = c(-0.5,0,0.5,1)) + scale_y_continuous(breaks = c(0,500,1000)) +
  geom_histogram(color="black", fill="gray")+
  facet_grid(Scenario_f ~ .) 

n <- 1000
median(r.Positive)
  # 0.9924985
median(r.Negative)
  # -0.001528197
median(r.Darwin)
  # 0.6658274
min(r.Darwin)
  # -0.2819705
max(r.Darwin)
  # 0.998801
median(r.Unrepburst)
  # 0.470313
min(r.Unrepburst)
  # -0.3963951
max(r.Unrepburst)
  # 0.9256394

error.positive <- qt(0.975,df=n-1)*sd(r.Positive)/sqrt(n)
left.positive <- mean(r.Positive) - error.positive
right.positive <- mean(r.Positive) + error.positive
  # 95% CI: 0.9887678,0.9900386
error.negative <- qt(0.975,df=n-1)*sd(r.Negative)/sqrt(n)
left.negative <- mean(r.Negative) - error.negative
right.negative <- mean(r.Negative) + error.negative
  # 95% CI: -0.01788919,0.01358786
error.Darwin <- qt(0.975,df=n-1)*sd(r.Darwin)/sqrt(n)
left.Darwin <- mean(r.Darwin) - error.Darwin
right.Darwin <- mean(r.Darwin) + error.Darwin
  # 95% CI: 0.6300023,0.657601
error.Unrepburst <- qt(0.975,df=n-1)*sd(r.Unrepburst)/sqrt(n)
left.Unrepburst <- mean(r.Unrepburst) - error.Unrepburst
right.Unrepburst <- mean(r.Unrepburst) + error.Unrepburst
  # 95% CI: 0.4234898,0.4535297