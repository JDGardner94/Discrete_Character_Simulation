# Comparing Darwin's and unreplicated burst scenarios
library(ggplot2)
library(plyr)
neworder <- c("Positive Control", "Negative Control", "Darwin's Scenario", "Unreplicated Burst")
Dataset2 <- arrange(transform(Simulation_MCMCglmm_results, Scenario=factor(Scenario,levels=neworder)),Scenario)
p <- ggplot(Dataset2, aes(x = pMCMC)) + geom_histogram(position = "dodge", alpha = 0.5, fill = "Black") + labs(x = "pMCMC") + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"), legend.position = "none")
p + geom_vline(xintercept = 0.05, linetype = 5, color = "gray") + scale_x_continuous(breaks = c(0.05,0.2,0.4)) + scale_y_continuous(breaks = c(0,500,1000)) + facet_wrap(Scenario ~ .) + theme(strip.background.x = element_blank())

p <- ggplot(Simulation_MCMCglmm_results, aes(x = Scenario, y = pMCMC)) + geom_tufteboxplot() + labs(y = "p-value", x = NULL) + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"), legend.position = "none")
#A point indicating the median, a gap indicating the interquartile range, and lines for whiskers
p + geom_hline(yintercept = 0.05, linetype = 5, color = "gray") + scale_x_discrete(limits=c("Positive Control", "Negative Control", "Darwin's Scenario", "Unreplicated Burst"))

Simulation_MCMCglmm_results$Scenario_f = factor(Simulation_MCMCglmm_results$Scenario, levels=c("Positive Control", "Negative Control", "Darwin's Scenario", "Unreplicated Burst"))

p<-ggplot(Simulation_MCMCglmm_results, aes(x=pMCMC))+ geom_histogram(position = "dodge", alpha = 0.5) + labs(x = "p-value") + theme(plot.background = element_rect(fill = "white"), panel.background = element_rect(fill = "white", colour = "white",linetype = "solid"), panel.grid.major = element_line(linetype = 'solid', colour = "white"), panel.grid.minor = element_line(linetype = 'solid', colour = "white"), text = element_text(colour = "black"), axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"), legend.background = element_rect(fill = "white"), legend.key = element_rect(fill = "white", colour = "white"))
p + scale_x_continuous(breaks = c(0.05,0.5,1)) + scale_y_continuous(breaks = c(0,500,1000)) +
  geom_histogram(color="black", fill="gray")+
  facet_grid(Scenario_f ~ .) 

n <- 1000
median(p.Positive)
  # 0.0006666667
median(p.Negative)
  # 0.4906667
median(p.Darwin)
  # 0.0006666667
min(p.Darwin)
  # 0.0006666667
max(p.Darwin)
  # 0.036
median(p.Unrepburst)
  # 0.1346667
min(p.Unrepburst)
  # 0.005333333
max(p.Unrepburst)
  # 0.3946667

error.positive <- qt(0.975,df=n-1)*sd(p.Positive)/sqrt(n)
left.positive <- mean(p.Positive) - error.positive
right.positive <- mean(p.Positive) + error.positive
  # 95% CI: 0.0006666667,0.0006666667
error.negative <- qt(0.975,df=n-1)*sd(p.Negative)/sqrt(n)
left.negative <- mean(p.Negative) - error.negative
right.negative <- mean(p.Negative) + error.negative
  # 95% CI: 0.4777177,0.5145077
error.Darwin <- qt(0.975,df=n-1)*sd(p.Darwin)/sqrt(n)
left.Darwin <- mean(p.Darwin) - error.Darwin
right.Darwin <- mean(p.Darwin) + error.Darwin
  # 95% CI: 0.0008798522,0.001116148
error.Unrepburst <- qt(0.975,df=n-1)*sd(p.Unrepburst)/sqrt(n)
left.Unrepburst <- mean(p.Unrepburst) - error.Unrepburst
right.Unrepburst <- mean(p.Unrepburst) + error.Unrepburst
  # 95% CI: 0.1396206,0.1473794
